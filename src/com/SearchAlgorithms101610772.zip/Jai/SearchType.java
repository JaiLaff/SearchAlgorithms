package com.Jai;

public enum SearchType {
    DEPTH,BREADTH,GREEDY,ASTAR
}
