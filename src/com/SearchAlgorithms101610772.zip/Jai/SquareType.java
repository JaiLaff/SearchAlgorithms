package com.Jai;

public enum SquareType {
    BLNK,GOAL,WALL, AGNT, PATH
}
