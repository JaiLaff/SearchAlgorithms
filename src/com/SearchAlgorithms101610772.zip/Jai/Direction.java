package com.Jai;

public enum Direction {
    UP,LEFT,DOWN,RIGHT,NONE
}
